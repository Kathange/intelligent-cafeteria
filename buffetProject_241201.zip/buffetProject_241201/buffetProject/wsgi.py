"""
WSGI config for buffetProject project.

It exposes the WSGI callable as a module-level variable named ``application``.

For more information on this file, see
https://docs.djangoproject.com/en/4.2/howto/deployment/wsgi/
"""

import os

from django.core.wsgi import get_wsgi_application


from interface._3D_query_food_info import query_food_info
import paramiko
# query_food_info()

# ec2_ip = '3.136.127.234'
# username = "Administrator"
# password = "uGUhyLJ.f(H!@A-&1xUeWB&9Bub81M@h"

# # 創建SSH client
# ssh = paramiko.SSHClient()
# ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
# # 連接EC2
# ssh.connect(hostname=ec2_ip, username=username, password=password)
# # 使用SFTP上傳圖片
# sftp = ssh.open_sftp()
# print("ssh打開")


os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'buffetProject.settings')

application = get_wsgi_application()
