import requests


# url = "http://127.0.0.1:8000/en/interface/getUserBool"
url = "https://3dbuffet.servebeer.com/endpoint"
data = {"add_database": "123"}  # 要发送的数据


# 发送 POST 请求
response = requests.post(url, json=data)


# 检查响应
if response.status_code == 200:
    print("成功发送消息:", response.json())
else:
    print("发送失败，状态码:", response.status_code)
