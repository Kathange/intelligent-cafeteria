"""

刪除多餘的檔案
除了防止抓取上一筆資料，也做為一個新流程的開始

"""



import os
from django.http import JsonResponse

def delete(request):
    if request.method == 'GET':
        # 如果 辨識照片 存在，就刪掉它
        image_path = '/home/jetson/Desktop/ds_test/bug/blend_image.jpg'
        if os.path.exists(image_path):
            os.remove(image_path)
        
        # 如果  存在，就刪掉它
        image_path = '/home/jetson/Desktop/ds_test/bug/mask_color.jpg'
        if os.path.exists(image_path):
            os.remove(image_path)
        
        # 如果 遮罩 存在，就刪掉它
        image_path = '/home/jetson/Desktop/ds_test/bug/total_mask.png'
        if os.path.exists(image_path):
            os.remove(image_path)

        # 如果 donut_chart 存在，就刪掉它
        image_path = './static/image/donut_chart_seller.png'
        if os.path.exists(image_path):
            os.remove(image_path)

        # 如果 table 存在，就刪掉它
        image_path = './static/image/sheet_img.png'
        if os.path.exists(image_path):
            os.remove(image_path)

        # 如果 circle 存在，就刪掉它
        image_path = './static/image/circle.png'
        if os.path.exists(image_path):
            os.remove(image_path)

        # 如果 screen_shot 存在，就刪掉它
        image_path = '/home/jetson/Desktop/ds_test/deteck/screenShot.jpg'
        if os.path.exists(image_path):
            os.remove(image_path)
        
        # 如果 screen_shot 存在，就刪掉它
        image_path = './static/deteck/screenShot.jpg'
        if os.path.exists(image_path):
            os.remove(image_path)

        # 如果 merge_data.txt 存在，就刪掉它
        file_path = './static/file/merged_data.txt'
        if os.path.exists(file_path):
            os.remove(file_path)

        # 如果 volume.txt 存在，就刪掉它
        file_path = './static/file/volume.txt'
        if os.path.exists(file_path):
            os.remove(file_path)
        
        # 如果 forUnet.csv 存在，就刪掉它
        file_path = './static/file/forUnet.csv'
        if os.path.exists(file_path):
            os.remove(file_path)

        # 如果 rfid.txt 存在，就刪掉它
        file_path = './static/file/rfid.txt'
        if os.path.exists(file_path):
            os.remove(file_path)

        # 如果 cashierOrWaste.txt 存在，就刪掉它
        file_path = './static/file/cashierOrWaste.txt'
        if os.path.exists(file_path):
            os.remove(file_path)
        print("delete in")

        return JsonResponse({'status': 'success'})



def negativeDelete():
    # 如果 辨識照片 存在，就刪掉它
    image_path = '/home/jetson/Desktop/ds_test/bug/blend_image.jpg'
    if os.path.exists(image_path):
        os.remove(image_path)
    
    # 如果  存在，就刪掉它
    image_path = '/home/jetson/Desktop/ds_test/bug/mask_color.jpg'
    if os.path.exists(image_path):
        os.remove(image_path)
    
    # 如果 遮罩 存在，就刪掉它
    image_path = '/home/jetson/Desktop/ds_test/bug/total_mask.png'
    if os.path.exists(image_path):
        os.remove(image_path)

    # 如果 screen_shot 存在，就刪掉它
    image_path = '/home/jetson/Desktop/ds_test/deteck/screenShot.jpg'
    if os.path.exists(image_path):
        os.remove(image_path)
    
    # 如果 screen_shot 存在，就刪掉它
    image_path = './static/deteck/screenShot.jpg'
    if os.path.exists(image_path):
        os.remove(image_path)

    # 如果 merge_data.txt 存在，就刪掉它
    file_path = './static/file/merged_data.txt'
    if os.path.exists(file_path):
        os.remove(file_path)

    # 如果 volume.txt 存在，就刪掉它
    file_path = './static/file/volume.txt'
    if os.path.exists(file_path):
        os.remove(file_path)
    
    # 如果 forUnet.csv 存在，就刪掉它
    file_path = './static/file/forUnet.csv'
    if os.path.exists(file_path):
        os.remove(file_path)
    
    # 如果 cashierOrWaste.txt 存在，就刪掉它
    file_path = './static/file/cashierOrWaste.txt'
    if os.path.exists(file_path):
        os.remove(file_path)

    print("negativeDelete in")
    return None
