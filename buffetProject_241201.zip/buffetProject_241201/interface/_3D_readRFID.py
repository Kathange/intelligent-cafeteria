"""

此為讀取RFID，並寫入資料庫(還要再改)

"""


from django.http import JsonResponse
import serial
from .models import user
from django.db import connection
import requests
import keyboard
import time
# from ._3D_query_food_info import connectin
# import _3D_query_food_info

# _3D_query_food_info.query_food_info()


def readRFID(request):
    if request.method == 'GET':
        # 记录开始时间
        start_time1 = time.time()

        serial_port = '/dev/ttyACM0'
        ser = serial.Serial(serial_port, 9600, timeout=1)
        # print("ser: ",ser)
        # print(type(ser))
        reading_flag = True

        # 计算处理时间
        end_time2 = time.time()
        processing_time2 = end_time2 - start_time1
        print(f"a_openportlog_joinMember: {processing_time2} seconds")
        # 记录开始时间
        start_time2 = time.time()
        try:
            while reading_flag:
                # 读取串口数据
                line = ser.readline().decode('utf-8').strip()
                # 如果数据包含 "UID Value:"，表示读取到 UID
                if "Card UID:" in line:
                    # 提取 UID 部分
                    uid_value = line.split(":")[1].strip()
                    print(f"Read UID: {uid_value}")
                    # Check if UID is a valid number (you may need to customize this validation)
                    reading_flag = False
                    
                    # 计算处理时间
                    end_time3 = time.time()
                    processing_time3 = end_time3 - start_time2
                    print(f"a_openportlog_joinMember: {processing_time3} seconds")
                    ser.close()


                    # 记录开始时间
                    start_time3 = time.time()
                    # Save merged data to a text file
                    with open('./static/file/rfid.txt', 'w') as file:
                        file.write(uid_value)
                    # 计算处理时间
                    end_time4 = time.time()
                    processing_time4 = end_time4 - start_time3
                    print(f"a_openportlog_joinMember: {processing_time4} seconds")
                    # 记录开始时间
                    start_time4 = time.time()

                    # 使用filter查找数据库中具有相同name的项
                    rfidExist = user.objects.filter(user_RFID=uid_value)
                    # 如果有任何一个项与给定的name匹配，返回True；否则返回False
                    is_duplicate = rfidExist.exists()
                    # cursor = connection.cursor()
                    # is_duplicate = cursor.execute(f"SELECT exist(select user_RFID FROM interface_user WHERE user_RFID = \"{uid_value}\")")
                    
                    # 计算处理时间
                    end_time5 = time.time()
                    processing_time5 = end_time5 - start_time4
                    print(f"a_openportlog_joinMember: {processing_time5} seconds")

                    # flask_url = "https://fb9c-220-128-241-244.ngrok-free.app/endpoint"
                    flask_url = "http://127.0.0.1:8080/endpoint"
                    # print(type(uid_value))
                    response = requests.post(flask_url, data={'endpoint':uid_value})
                    if response.status_code == 200:
                        print('success')
                    else:
                        print('failed', response.status_code)
                    
                    # 计算处理时间
                    end_time1 = time.time()
                    processing_time1 = end_time1 - start_time1
                    print(f"a_fetchlog_joinMember: {processing_time1} seconds")

                    if is_duplicate:
                        # ser.close()
                        return JsonResponse({'uid': "none"})
                    
                    # ser.close()
                    return JsonResponse({'uid': uid_value})
                
                if "red" in line:
                    ser.close()
                    print("red_btn is clicked")
                    return JsonResponse({'uid': "notJoin"})
                
        except KeyboardInterrupt:
            print("Program terminated by user.")
            ser.close()
        finally:
            ser.close()




# # interface/views.py

# # from django.http import JsonResponse
# # import time
# from arduinoPort.serial_manage import SerialPortManager
# # from .models import user  # 假设您的模型位于此处
# # import requests

# def readRFID(request):
#     if request.method == 'GET':
#         # 记录开始时间
#         start_time1 = time.time()

#         # 获取串口管理器实例
#         port_manager = SerialPortManager()

#         # 获取最新的 UID 数据
#         uid_value = port_manager.get_latest_uid()

#         if uid_value:
#             print(f"Read UID: {uid_value}")

#             # 计算处理时间
#             end_time3 = time.time()
#             processing_time3 = end_time3 - start_time1
#             print(f"a_openportlog_joinMember: {processing_time3} seconds")

#             # Save merged data to a text file
#             with open('./static/file/rfid.txt', 'w') as file:
#                 file.write(uid_value)
#             # 计算处理时间
#             end_time4 = time.time()
#             processing_time4 = end_time4 - end_time3
#             print(f"a_openportlog_joinMember: {processing_time4} seconds")

#             # 使用filter查找数据库中具有相同user_RFID的项
#             rfidExist = user.objects.filter(user_RFID=uid_value)
#             # 判断是否存在重复
#             is_duplicate = rfidExist.exists()
#             # 计算处理时间
#             end_time5 = time.time()
#             processing_time5 = end_time5 - end_time4
#             print(f"a_openportlog_joinMember: {processing_time5} seconds")

#             # 发送请求到 Flask 应用
#             flask_url = "http://127.0.0.1:8080/endpoint"
#             response = requests.post(flask_url, data={'endpoint': uid_value})
#             if response.status_code == 200:
#                 print('success')
#             else:
#                 print('failed', response.status_code)
#             # 计算处理时间
#             end_time1 = time.time()
#             processing_time1 = end_time1 - start_time1
#             print(f"a_fetchlog_joinMember: {processing_time1} seconds")

#             if is_duplicate:
#                 return JsonResponse({'uid': "none"})
#             else:
#                 return JsonResponse({'uid': uid_value})
#         else:
#             # 如果没有新的 UID 数据，返回提示
#             return JsonResponse({'error': 'No new UID available'})



# 如果來亂的，不加入又掃，就傳訊息把它刪了
def onclick():
    # flask_url = "https://fb9c-220-128-241-244.ngrok-free.app/deleteData"
    flask_url = "http://127.0.0.1:8080/deleteData"
    response = requests.post(flask_url, data={'delete_data':"1"})
    if response.status_code == 200:
        print('success')
    else:
        print('failed', response.status_code)
    # print("onclick in")
    return JsonResponse({'status': 'success'})


