"""

偵測按鈕是否被按下

"""



import serial
from django.http import JsonResponse
import time
from arduinoPort.serial_manage import SerialPortManager


def changePage(request):
    if request.method == "GET":
        # 记录开始时间
        start_time = time.time()

        # 初始化串口通信
        serial_port = '/dev/ttyACM0'  # 修改为你的串行端口
        ser = serial.Serial(serial_port, 9600, timeout=1)

        try:
            while True:
                # 从串行端口读取一行数据
                line = ser.readline().decode('utf-8').strip()
                    
                if "red" in line:
                    ser.close()
                    print("red_btn is clicked")
                    # Save merged data to a text file
                    with open('./static/file/cashierOrWaste.txt', 'w') as file:
                        file.write("red")
                    # 计算处理时间
                    end_time = time.time()
                    processing_time = end_time - start_time
                    print(f"d_btnlog_button: {processing_time} seconds")
                    return JsonResponse({'btn': 'red'})
                if "black" in line:
                    ser.close()
                    print("black_btn is clicked")
                    # Save merged data to a text file
                    with open('./static/file/cashierOrWaste.txt', 'w') as file:
                        file.write("black")
                    # 计算处理时间
                    end_time = time.time()
                    processing_time = end_time - start_time
                    print(f"d_btnlog_button: {processing_time} seconds")
                    return JsonResponse({'btn': 'black'})
        except KeyboardInterrupt:
            print("Program terminated by user.")
        finally:
            ser.close()  # 关闭串行端口




# def changePage(request):
#     if request.method == "GET":
#         # 记录开始时间
#         start_time = time.time()

#         # 获取串口管理器实例
#         port_manager = SerialPortManager()

#         while True:
#             # 获取最新的串口数据
#             line = port_manager.get_latest_line()

#             if line:
#                 if "red" in line:
#                     print("red_btn is clicked")
#                     # 计算处理时间
#                     end_time = time.time()
#                     processing_time = end_time - start_time
#                     print(f"d_btnlog_button: {processing_time} seconds")
#                     return JsonResponse({'btn': 'red'})
#                 elif "black" in line:
#                     print("black_btn is clicked")
#                     # 计算处理时间
#                     end_time = time.time()
#                     processing_time = end_time - start_time
#                     print(f"d_btnlog_button: {processing_time} seconds")
#                     return JsonResponse({'btn': 'black'})
#                 else:
#                     return JsonResponse({'btn': 'unknown'})
#             else:
#                 return JsonResponse({'error': 'No data available'})

        
        

