from django.shortcuts import render, redirect
from .models import *
from django.http.response import StreamingHttpResponse
from django.http import JsonResponse
import os
import requests
from django.core.exceptions import ObjectDoesNotExist
import time

from ._3D_camera import FoodVedioCamera
from ._3D_getDB import getDBAllData
# from ._3D_writeDB import writeDB
from ._3D_unetinput import doing, readDB
from ._3D_readRFID import onclick
from ._3D_delete import negativeDelete


    

# 設置 camera (要把模型放進去應該去camera.py寫)
def gen(camera):
    while True:
        frame = camera.get_frame()
        yield(b'--frame\r\n'
                b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n\r\n')

# 連接攝影機(特定語法，應該，我是複製貼上)，gen(camera.py中的class)
def FoodVedioFeed(request):
    return StreamingHttpResponse(gen(FoodVedioCamera()),
                                 content_type='multipart/x-mixed-replace; boundary=frame')
    

# 關於我們的頁面
def about(request):
    return render(request, 'interface/about.html')

# 加入會員頁面
def joinMember(request):
    return render(request, 'interface/joinMember.html')

# 開啟攝影機頁面
def camera(request):
    # # 记录开始时间
    # start_time = time.time()

    # # getDBAllData()
    # onclick()
    # # file_path = './static/file/rfid.txt'
    # # # 檢查檔案是否存在
    # # if os.path.exists(file_path):
    # #     # 打開檔案 讀取內容
    # #     with open('./static/file/rfid.txt', 'r') as file:
    # #         rfid_data = file.read()
    # #     try:
    # #         buyer = user.objects.get(user_RFID=rfid_data)
    # #         # 如果成功取得 user 物件，這裡執行存在時的動作
    # #         print("camera in rfid")
    # #     except ObjectDoesNotExist:
    # #         # 如果找不到對應的 user 物件，這裡執行不存在時的動作
    # #         print("camera delete rfid")
    # #         os.remove(file_path)
    # # else:
    # #     pass
    
    # # 计算处理时间
    # end_time = time.time()
    # processing_time = end_time - start_time
    # print(f"b_loadrfidlog_camera: {processing_time} seconds")

    if request.method == 'POST':
        # 记录开始时间
        start_time = time.time()
        onclick()
        # 计算处理时间
        end_time = time.time()
        processing_time = end_time - start_time
        print(f"b_loadrfidlog_camera: {processing_time} seconds")

        doing()
        # ngrok_url = requests.get("http://127.0.0.1:4040/api/tunnels").json()['tunnels'][0]['public_url']
        # return redirect(f'{ngrok_url}/interface/cashier')
        # return redirect('https://e614-61-218-122-234.ngrok-free.app/interface/cashier')
        return redirect('http://127.0.0.1:8000/interface/cashier')

    return render(request, 'interface/camera.html')

# 收銀區頁面
def cashier(request):
    # 如果體積檔案根本不在，就跳到negative.html
    if not os.path.exists('./static/file/volume.txt'):
        negativeDelete()
        return render(request, 'interface/negative.html')
    
    # 记录开始时间
    start_time1 = time.time()
    
    # Read merged data from the text file
    volume_data = []
    # Read data from 'volume.txt'
    with open('./static/file/volume.txt', 'r') as file:
        volume_data = [list(map(float, line.strip().split(','))) for line in file]
    # Flatten the volume_data list to a 1D list
    read_volume = []
    for sublist in volume_data:
        read_volume.extend(sublist)
    # print(read_volume)
    # 如果體積出現負值，就跳到negative.html
    if read_volume[0]<0 or read_volume[1]<0 or read_volume[2]<0:
        negativeDelete()
        return render(request, 'interface/negative.html')
    
    # 计算处理时间
    end_time1 = time.time()
    processing_time1 = end_time1 - start_time1
    print(f"c_getvolumelog_cashier: {processing_time1} seconds")

    # # 记录开始时间
    # start_time2 = time.time()
    
    # file_path = './static/file/rfid.txt'
    # # 檢查檔案是否存在
    # if os.path.exists(file_path):
    #     # 打開檔案 讀取內容
    #     with open('./static/file/rfid.txt', 'r') as file:
    #         rfid_data = file.read()

    #     # 计算处理时间
    #     end_time3 = time.time()
    #     processing_time3 = end_time3 - start_time2
    #     print(f"c_openrfidlog_cashier: {processing_time3} seconds")
    #     try:
    #         buyer = user.objects.get(user_RFID=rfid_data)
    #         # 如果成功取得 user 物件，這裡執行存在時的動作
    #         print("member in")
    #         writeDB()
    #     except ObjectDoesNotExist:
    #         # 如果找不到對應的 user 物件，這裡執行不存在時的動作
    #         flask_url = "https://c763-61-218-122-232.ngrok-free.app/newRecord"
    #         # print(type(uid_value))
    #         response = requests.post(flask_url, data={'new_record':"1"})
    #         if response.status_code == 200:
    #             print('success')
    #         else:
    #             print('failed', response.status_code)
    # else:
    #     pass

    # # 计算处理时间
    # end_time2 = time.time()
    # processing_time2 = end_time2 - start_time2
    # print(f"c_checkrfidlog_cashier: {processing_time2} seconds")
    
    cost = int(round(read_volume[0], 0))
    weight = round(read_volume[1], 3)
    calories = round(read_volume[2], 3)
    context = {'cost': cost, 'weight': ("%.03f" % weight), 'calories': ("%.03f" % calories)}
    return render(request, 'interface/cashier.html',context)

# 出現負值的頁面
def negative(request):
    return render(request, 'interface/negative.html')


import json
joinData = {"add_database": " "}
def getUserBool(request):
    global joinData
    if request.method == "GET":
        try:
            # 获取并解析请求中的 JSON 数据
            joinData = json.loads(request.body)
            print("接收到的数据:", joinData)
           
            # 使用判斷式檢查
            if 'add_database' in joinData and joinData['add_database'] == '1':
                return JsonResponse({'Thanks': "1"})

            # 返回成功响应
            return JsonResponse({"status": "success", "message": "Data received successfully"})
       
        except json.JSONDecodeError:
            # 使用判斷式檢查
            if 'add_database' in joinData and joinData['add_database'] == '123':
                return JsonResponse({'Thanks': "1"})
           
            return JsonResponse({'Thanks': "timeout", "status": "error", "message": "Invalid JSON data"}, status=400)
    else:
        return JsonResponse({'Thanks': "timeout", "status": "error", "message": "Invalid request method"}, status=405)






# 顯示圖片(不重要，紀念用而已)
# def img(request):
#     # 讀取圖片
#     img = cv2.imread('./media/interface/Totoro.png')
#     img = cv2.resize(img, (0,0), fx=0.5, fy=0.5)
#     _, image_encoded = cv2.imencode('.jpg', img) 
#     return HttpResponse(image_encoded.tostring(), content_type='image/jpeg') 

