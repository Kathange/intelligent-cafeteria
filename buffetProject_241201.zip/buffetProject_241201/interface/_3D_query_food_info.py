import pymysql
import csv


global connectin

def query_food_info():
    global connectin
    # 連接 MySQL 資料庫
    connectin = pymysql.connect(
        host='3.136.127.234',
        user='project',
        password='3dbuffet',
        database='3d_buffet'
    )


    try:
        # 建立游標物件
        cursor = connectin.cursor()
       
        # 執行 SQL 查詢
        query = "SELECT * FROM interface_provide_food where 1"
        cursor.execute(query)
       
        # 取得所有查詢結果
        food_name = cursor.fetchall()
        # print(food_name)
        # print(food_name[0][0])


        food_id = []
        for i in range(len(food_name)):
            query = f"SELECT food_id FROM interface_food_code where name = \"{food_name[i][0]}\""
            cursor.execute(query)
            food_id.append(cursor.fetchone())


        # print(food_id)


        food_info = []
        for i in range(len(food_id)):
            query = f"SELECT * FROM interface_food_info where food_id = \"{food_id[i][0]}\""
            cursor.execute(query)
            food_info.append(cursor.fetchone())


        # print(food_info)


        with open("./static/file/food_info.csv", mode="w", newline="", encoding="utf-8") as file:
            writer = csv.writer(file)
            writer.writerow(["food_name", "weight", "calorie", "protein", "carbonhydrate", "fat", "cost", "is_bone"])


            for i in range(len(food_name)):
                row = [food_name[i][0]] + list(food_info[i][1:])
                writer.writerow(row)


    finally:
    #     # 關閉游標和連線
        cursor.close()
    #     connection.close()


    print("資料已成功寫入 output.csv")


